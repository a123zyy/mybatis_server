// url的链接
export const urls: object = {
  login: "/web/login/login",
  logout: "logout",
  register: "register",
  getUser: "getUser",

  addComment: "/web/CommentInfo/addCommentInfo",
  addThirdComment: "/web/CommentInfo/addCommentInfo",
  getCommentList: "getCommentList",

  getPostListByYear: "/web/PostInfo/postinfosBycreateTime",
  getArticleList: "/web/PostInfo/posts",

  likeArticle: "/web/PostInfo/likes",
  getArticleDetail: "/web/PostInfo/getPostById",

  addMessage: "addMessage",
  getMessageList: "getMessageList",
  getMessageDetail: "getMessageDetail",

  getLinkList: "getLinkList",

  getTagList: "/web/LabelInfo/LabelInfo",

  getCategoryList: "getCategoryList",

  getTimeAxisList: "getTimeAxisList",
  getTimeAxisDetail: "getTimeAxisDetail",

  getProjectList: "getProjectList",
  getProjectDetail: "getProjectDetail"
};

export default urls;
